package com.nesger.viewstubdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewStub;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private ViewStub mViewStub;
    private View mStubView;
    private Button mBtnDelay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mViewStub = findViewById(R.id.view_stub);
    }


    public void directlyShow(View v) {
        if (mStubView == null) {
            //防止多次调用报错，大家可以测试下，不加判断，多次调用会报错
            mStubView = mViewStub.inflate();
        }
        if (mBtnDelay == null) {
            mBtnDelay = mStubView.findViewById(R.id.btn_delay);
        }
        if (mBtnDelay != null) {
            mBtnDelay.setText("change");
        }
    }

}
