# ViewStubDemo

Android布局优化ViewStub示例

具体说明见[简书](https://www.jianshu.com/p/685c673f932c)
