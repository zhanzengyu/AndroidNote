#!/bin/sh
#########################################
# File Name: run.sh
# Version: v1.0
# Author: zhanzengyu
# Email: 553838510@qq.com
#########################################

echo "--------开始日志神器的配置---------"
chmod u+x ./adb
chmod u+x ./logcat.sh
echo "--------请输入电脑密码-----------"
sudo cp ./adb /usr/local/bin
mv ./logcat.sh ~/Documents
touch ~/.zshrc
echo "alias logcat='~/Documents/logcat.sh'" >>  ~/.zshrc
echo "------日志神器配置还差最后一步---------"
echo "请拷贝下面命令到终端执行以完成日志神器的配置，之后你就可以在命令行输入 logcat 来抓取日志了，记得连接上设备哦～"
echo "source ~/.zshrc"
